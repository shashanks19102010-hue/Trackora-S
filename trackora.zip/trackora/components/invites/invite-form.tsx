"use client";

import { useState, useTransition } from "react";
import { UserPlus } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toaster";
import { createInviteAction } from "@/app/(dashboard)/invites/actions";

const RELATIONSHIPS = [
  { value: "family", label: "Family" },
  { value: "friend", label: "Friend" },
  { value: "colleague", label: "Colleague" },
  { value: "other", label: "Other" },
];

export function InviteForm() {
  const [isPending, startTransition] = useTransition();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [relationship, setRelationship] = useState("family");
  const { toast } = useToast();

  function handleSubmit(formData: FormData) {
    formData.set("relationship", relationship);
    setErrors({});
    startTransition(async () => {
      const result = await createInviteAction(formData);
      if (result.fieldErrors) {
        const flat: Record<string, string> = {};
        for (const k in result.fieldErrors) flat[k] = result.fieldErrors[k]?.[0] ?? "";
        setErrors(flat);
      }
      toast({
        title: result.success ? "Invite sent" : "Couldn't send invite",
        description: result.message,
        variant: result.success ? "success" : "error",
      });
      if (result.success) (document.getElementById("invite-form") as HTMLFormElement)?.reset();
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="h-5 w-5 text-signal" /> Invite someone
        </CardTitle>
        <CardDescription>
          They'll get a request to share locations with you. Nothing shows on your map until they say yes.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form id="invite-form" action={handleSubmit} className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="label">Name</Label>
            <Input id="label" name="label" placeholder="e.g. Mom" required error={errors.label} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="phone">Phone number</Label>
            <Input id="phone" name="phone" placeholder="+14155551234" required error={errors.phone} />
            {errors.phone && <p className="text-xs text-destructive">{errors.phone}</p>}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="email">Email (optional)</Label>
            <Input id="email" name="email" type="email" placeholder="optional@example.com" />
          </div>
          <div className="space-y-1.5">
            <Label>Relationship</Label>
            <div className="flex flex-wrap gap-2">
              {RELATIONSHIPS.map((r) => (
                <button
                  type="button"
                  key={r.value}
                  onClick={() => setRelationship(r.value)}
                  className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                    relationship === r.value ? "bg-signal text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
          <div className="md:col-span-2">
            <Button type="submit" loading={isPending}>
              Send invite
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
