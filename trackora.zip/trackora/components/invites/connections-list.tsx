"use client";

import { useTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, Ban } from "lucide-react";
import { Button } from "@/components/ui/button";
import { respondToInviteAction, revokeConnectionAction } from "@/app/(dashboard)/invites/actions";

interface Connection {
  id: string;
  label: string;
  status: string;
  relationship: string;
  invited_phone: string;
  owner?: { full_name: string } | null;
}

export function ConnectionsList({
  title,
  connections,
  variant,
}: {
  title: string;
  connections: Connection[];
  variant: "incoming" | "outgoing";
}) {
  const [isPending, startTransition] = useTransition();

  if (connections.length === 0) return null;

  return (
    <div>
      <h2 className="mb-3 font-display text-lg font-semibold">{title}</h2>
      <div className="space-y-2">
        <AnimatePresence>
          {connections.map((c) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="glass-panel flex items-center justify-between rounded-xl p-4"
            >
              <div>
                <p className="text-sm font-medium">
                  {variant === "incoming" ? c.owner?.full_name ?? "Someone" : c.label}
                </p>
                <p className="mono-readout">
                  {c.relationship} · {c.status} · {c.invited_phone}
                </p>
              </div>

              {variant === "incoming" && c.status === "pending" && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    loading={isPending}
                    onClick={() => startTransition(() => respondToInviteAction(c.id, "accept"))}
                  >
                    <Check className="h-4 w-4" /> Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => startTransition(() => respondToInviteAction(c.id, "decline"))}
                  >
                    <X className="h-4 w-4" /> Decline
                  </Button>
                </div>
              )}

              {variant === "outgoing" && c.status === "accepted" && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => startTransition(() => revokeConnectionAction(c.id))}
                >
                  <Ban className="h-4 w-4" /> Revoke
                </Button>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
