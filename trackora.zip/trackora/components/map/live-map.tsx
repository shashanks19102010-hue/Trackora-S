"use client";

import * as React from "react";
import { GoogleMap, useJsApiLoader, OverlayView } from "@react-google-maps/api";
import { formatDistanceToNow } from "date-fns";
import { createClient } from "@/lib/supabase/client";
import { formatCoordinate } from "@/lib/utils";

interface PersonLocation {
  owner_id: string;
  lat: number;
  lng: number;
  accuracy_meters: number | null;
  captured_at: string;
}

interface Person {
  id: string;
  name: string;
  avatarUrl: string | null;
  location: PersonLocation | null;
}

const MAP_CONTAINER_STYLE = { width: "100%", height: "100%" };
const DEFAULT_CENTER = { lat: 20.5937, lng: 78.9629 }; // India-centered default

// Nothing-OS-inspired dark map theme — desaturated, high-contrast labels.
const DARK_MAP_STYLE = [
  { elementType: "geometry", stylers: [{ color: "#0e1013" }] },
  { elementType: "labels.text.stroke", stylers: [{ color: "#0e1013" }] },
  { elementType: "labels.text.fill", stylers: [{ color: "#8b92a3" }] },
  { featureType: "road", elementType: "geometry", stylers: [{ color: "#1c1f24" }] },
  { featureType: "water", elementType: "geometry", stylers: [{ color: "#0a0c10" }] },
  { featureType: "poi", stylers: [{ visibility: "off" }] },
  { featureType: "transit", stylers: [{ visibility: "off" }] },
];

export function LiveMap({ people, selfUserId }: { people: Person[]; selfUserId: string }) {
  const [livePeople, setLivePeople] = React.useState(people);
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ?? "",
    id: "trackora-map",
  });

  // Subscribe to new pings in real time so markers move the instant someone's
  // location updates — no polling, no page refresh.
  React.useEffect(() => {
    const supabase = createClient();
    const channel = supabase
      .channel("location-updates")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "location_pings" },
        (payload) => {
          const row = payload.new as PersonLocation;
          setLivePeople((prev) =>
            prev.map((p) => (p.id === row.owner_id ? { ...p, location: row } : p))
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selfUserId]);

  const withLocation = livePeople.filter((p) => p.location);
  const center = withLocation[0]?.location
    ? { lat: withLocation[0].location!.lat, lng: withLocation[0].location!.lng }
    : DEFAULT_CENTER;

  if (!process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY) {
    return (
      <div className="flex h-full items-center justify-center bg-secondary/40 p-8 text-center text-sm text-muted-foreground">
        Add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to your environment variables to enable the live map.
      </div>
    );
  }

  if (!isLoaded) {
    return <div className="flex h-full animate-pulse items-center justify-center bg-secondary/40 text-sm text-muted-foreground">Loading map…</div>;
  }

  return (
    <GoogleMap
      mapContainerStyle={MAP_CONTAINER_STYLE}
      center={center}
      zoom={withLocation.length ? 11 : 4}
      options={{
        styles: DARK_MAP_STYLE,
        disableDefaultUI: true,
        zoomControl: true,
        clickableIcons: false,
      }}
    >
      {withLocation.map((person) => (
        <OverlayView
          key={person.id}
          position={{ lat: person.location!.lat, lng: person.location!.lng }}
          mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
        >
          <SignalPin person={person} />
        </OverlayView>
      ))}
    </GoogleMap>
  );
}

function SignalPin({ person }: { person: Person }) {
  if (!person.location) return null;
  return (
    <div className="-translate-x-1/2 -translate-y-full flex flex-col items-center">
      <div className="glass-panel mb-1 whitespace-nowrap rounded-lg px-2 py-1 text-xs font-medium text-fog shadow-lg">
        {person.name}
        <div className="mono-readout mt-0.5">
          {formatCoordinate(person.location.lat)}, {formatCoordinate(person.location.lng)} ·{" "}
          {formatDistanceToNow(new Date(person.location.captured_at), { addSuffix: true })}
        </div>
      </div>
      <div className="relative flex h-4 w-4 items-center justify-center">
        <span className="absolute inline-flex h-full w-full animate-signal-pulse rounded-full bg-signal" />
        <span className="relative inline-flex h-3 w-3 rounded-full bg-signal ring-2 ring-white/80" />
      </div>
    </div>
  );
}
