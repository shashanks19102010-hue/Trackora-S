import { createClient } from "@/lib/supabase/server";
import { InviteForm } from "@/components/invites/invite-form";
import { ConnectionsList } from "@/components/invites/connections-list";

export default async function InvitesPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: sentInvites } = await supabase
    .from("connections")
    .select("*")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false });

  const { data: receivedInvites } = await supabase
    .from("connections")
    .select("*, owner:profiles!connections_owner_id_fkey(full_name)")
    .eq("connected_user_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold">Your circle</h1>
        <p className="text-sm text-muted-foreground">
          Nobody appears on your map until they accept your invite. You can revoke access at any time.
        </p>
      </div>

      <InviteForm />

      <ConnectionsList
        title="Pending responses"
        connections={(receivedInvites ?? []).filter((c) => c.status === "pending")}
        variant="incoming"
      />

      <ConnectionsList title="Sent invites" connections={sentInvites ?? []} variant="outgoing" />
    </div>
  );
}
