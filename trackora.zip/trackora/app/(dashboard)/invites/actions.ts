"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { inviteSchema } from "@/lib/validation/schemas";
import { logger } from "@/lib/logger";

export async function createInviteAction(formData: FormData) {
  const parsed = inviteSchema.safeParse({
    label: formData.get("label"),
    phone: formData.get("phone"),
    email: formData.get("email") || "",
    relationship: formData.get("relationship"),
  });

  if (!parsed.success) {
    return { success: false, fieldErrors: parsed.error.flatten().fieldErrors };
  }

  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { success: false, message: "Not authenticated" };

  // If someone with this phone already has an account, link the invite to
  // them directly; otherwise it stays pending until they sign up and match.
  const { data: existingProfile } = await supabase
    .from("profiles")
    .select("id")
    .eq("phone", parsed.data.phone)
    .maybeSingle();

  const { error } = await supabase.from("connections").insert({
    owner_id: user.id,
    connected_user_id: existingProfile?.id ?? null,
    invited_phone: parsed.data.phone,
    invited_email: parsed.data.email || null,
    label: parsed.data.label,
    relationship: parsed.data.relationship,
  });

  if (error) {
    logger.error("invite_create_failed", { message: error.message });
    return { success: false, message: "Couldn't send the invite. Try again." };
  }

  revalidatePath("/invites");
  return { success: true, message: `Invite sent to ${parsed.data.label}. It'll activate once they accept.` };
}

export async function respondToInviteAction(connectionId: string, action: "accept" | "decline") {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { success: false };

  const { error } = await supabase
    .from("connections")
    .update({
      status: action === "accept" ? "accepted" : "declined",
      connected_user_id: user.id,
      responded_at: new Date().toISOString(),
    })
    .eq("id", connectionId);

  if (error) {
    logger.error("invite_respond_failed", { message: error.message });
    return { success: false };
  }

  revalidatePath("/invites");
  return { success: true };
}

export async function revokeConnectionAction(connectionId: string) {
  const supabase = createClient();
  const { error } = await supabase.from("connections").update({ status: "revoked" }).eq("id", connectionId);
  revalidatePath("/invites");
  return { success: !error };
}
